
document.getElementById('logout').addEventListener('click', () => {
  localStorage.clear();
  alert('Sesión cerrada. Datos borrados del almacenamiento local.');
});

const saveData = (key, value) => {
  localStorage.setItem(key, JSON.stringify(value));
  showToast('Guardado correctamente');
};

function showToast(message) {
  const toast = document.createElement('div');
  toast.innerText = message;
  toast.style.position = 'fixed';
  toast.style.bottom = '20px';
  toast.style.right = '20px';
  toast.style.backgroundColor = '#000';
  toast.style.color = '#fff';
  toast.style.padding = '10px 20px';
  toast.style.borderRadius = '5px';
  toast.style.zIndex = 1000;
  document.body.appendChild(toast);
  setTimeout(() => toast.remove(), 3000);
}
